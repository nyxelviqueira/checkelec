const express = require("express");
const app = express();
const cors = require("cors");
const path = require("path");
const sqlite3 = require("sqlite3").verbose();

var corsOptions = {
  origin: function (origin, callback) {
    var whiteList = [
      "https://checkelec.ramonviqueira.com",
      "http://localhost:3000",
    ];

    if (whiteList.indexOf(origin) !== -1 || !origin) {
      callback(null, true);
    } else {
      callback(new Error("Not allowed by CORS"));
    }
  },
  optionsSuccessStatus: 200,
};

app.use(cors(corsOptions));

app.get("/api/data", (req, res) => {
  // Abrimos la conexión a la base de datos
  let db = new sqlite3.Database(
    path.resolve(__dirname, "db/my_database.db"),
    sqlite3.OPEN_READONLY,
    (err) => {
      if (err) {
        console.error(err.message);
        res
          .status(500)
          .json({ message: "Error al conectar con la base de datos" });
        return;
      }
    }
  );

  try {
    const currentDate = new Date().toDateString();
    db.get("SELECT * FROM data WHERE date = ?", currentDate, (err, row) => {
      if (err) {
        console.error(err.message);
        res.status(500).json({ message: "Error al obtener los datos" });
        return;
      }

      if (row) {
        res.json(JSON.parse(row.apiData));
      } else {
        res.status(404).json({ message: "No data available for today" });
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Error al obtener los datos" });
  } finally {
    // Cerramos la conexión a la base de datos
    db.close((err) => {
      if (err) {
        console.error(err.message);
      }
    });
  }
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
